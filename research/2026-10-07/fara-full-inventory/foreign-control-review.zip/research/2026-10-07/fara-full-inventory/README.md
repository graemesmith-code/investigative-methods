# Final report available

Start with [REPORT.md](REPORT.md), [ANNEX.md](ANNEX.md) and foreign-control-final.pdf. The final bundle is foreign-control-review.zip. Earlier checkpoints are historical, not the final assessment.

# Full FARA inventory continuation

This continues private checkpoint `750aa5eb3f4a2166451939db03f34ea26fd1d2aa`. The user supplied the three official CSV exports on `main`; their immutable source commit is `8557d0d9c6b8c1effe2d53e8b95d2425cb6d0e5f`. The copied CSV bytes have matching Git blob hashes and independent SHA-256 hashes in `supplied-source-provenance.json`. Unrelated uploads and earlier reports are retained.

The exports contain **7,090 registrant rows**, **17,765 principal relationship rows**, and **154,309 document rows**. Registrants cover 7,089 registration numbers, with 538 nonterminated and 6,552 terminated rows. Principal relationships contain 822 nonterminated and 16,943 terminated rows after explicit CSV repair. The export supplies no separate official principal ID: local row numbers are evidence locators, not legal-entity identifiers. One registration number has two distinct termination rows; those are not silently deduplicated.

All principal and document registration numbers occur in the registrant export. There are 126,481 distinct URL-field values, including the non-URL `Available-FARA-Public-Office`, which occurs on 27,814 document rows. The catalog therefore does not promise remotely retrievable PDFs for every record. Duplicate URLs can associate one filing with multiple principals; document-row count is not distinct-PDF count. The catalog contains 6,015 rows stamped in 2025. Some registrants have no document rows, which is not proof that they never filed.

The exports use the documented ISO-8859-1 encoding. Original bytes are unchanged. The 15 malformed-width principal records have explicit, reversible recovery records in `csv-parse-audit.json`, preserving raw logical records, standard parses, literal-delimiter recovery and physical line spans. Quoted fields can span physical lines. C1 characters must not be mistaken for newline boundaries. Other quote-rendering differences remain flagged for original-document verification. Registration numbers and date columns validate after recovery. One document date, `11/16/0200`, parses syntactically but is implausible and is not silently corrected.

Registration and principal dates range from 1942 to 2 October 2026; document stamps reach 6 October 2026. Exact publication times are unavailable. These are user-supplied exports attributed to DOJ; GitHub identity is verified, but the files were not independently checksum-matched against blocked DOJ downloads. Nonterminated status describes this snapshot, not every historical date. Inventory completeness, available-document completeness, acquired-original completeness and legal-analysis completeness are separate measures.

Run `python ingest.py` to validate originals and rebuild the ignored SQLite working database. Run `python join_cohort.py` to reproduce source-driven discovery edges against the previously fixed 259 LDA client relationships. Edges do not establish identity, foreign control, a disclosure obligation, or concealment. Case assessment and original retrieval continue incrementally.

No paid calls have been made in this continuation. The cumulative prior Jev estimate remains $0.003035; the same $15 ceiling applies. Legal ranking remains unvalidated and no new numerical legal scores are asserted.

## Expanded archive checkpoint

The five official House 2025 XML archives (four quarters and registrations) are acquired and checksum-recorded in `house-archive-downloads.json`. `parse_house.py` parsed all **109,389 XML records**, representing 23,776 distinct client-name strings and 28,341 House relationship identifiers. Four invalid XML character references in issue descriptions required explicitly logged, reversible literal escaping; none were silently discarded. ZIP originals remain local and reproducibly downloadable; selected original LDA forms are tracked separately.

`match_full_inventory.py` screens all 17,765 FARA principal rows against those client names. It preserves **598 discovery edges**, including historical and inconsistent-date relationships, without asserting legal identity. Thirteen matched lobbying relationships provisionally exceed $1 million in annual income or expenses. Annual amounts use one latest signed archive form per quarter and require reconciliation against API posting chronology and original forms. In-house expenses and outside-firm income are not added together, and neither measures foreign funding.

All-years histories for these thirteen relationships are complete: 981 originals, recorded in `major-history-coverage.json`. All 66 acquired 2025 quarterly amount pairs (including two additional Gotion relationships) agree with independent extraction from originals. Read `CHECKPOINT.md` for current findings and remaining work. A historical FARA termination does not establish termination of ownership. No new Jev calls were made. This is an acquisition checkpoint, not a completed ranking or a concealment finding.

Gotion supplies useful counterevidence: the original in-house, Mercury, and Vogel registrations each expressly answer Yes to foreign entities and name a Chinese parent at 100%. Its FARA Exhibit A also expressly names an owner. The difference between an immediate and ultimate parent needs chain verification and is not itself evidence of concealment. The issuer's original 2024 annual report is preserved, including the subsidiary table; translated subsidiary naming still needs exact legal-entity reconciliation.
