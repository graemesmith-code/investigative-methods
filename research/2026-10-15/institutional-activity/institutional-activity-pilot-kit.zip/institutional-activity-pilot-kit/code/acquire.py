"""Download bounded, public station aggregates; no person identifiers.
Uses the dashboard's guest export permissions. Run from the kit directory.
"""
from tableau_public import PublicTableau
from pathlib import Path
import json,datetime,csv,sys
ROOT=Path(__file__).resolve().parents[1]
STATIONS=['Pentagon','Pentagon City','Rosslyn','Crystal City']
PERIODS={'pm_peak':'PM Peak (3pm-7pm)','evening':'Evening (7pm-12am)'}
manifest=[]
def collect(station):
 local_manifest=[]
 slug=station.lower().replace(' ','_')
 c=PublicTableau('TotalEntriesandExitsbyDay',ROOT/'acquisition_work'/slug)
 c.filter('Day of Week',['Mon','Tue','Wed','Thu','Fri','Sat','Sun'])
 c.filter('Holiday',['No','Yes'])
 c.filter('Station Name',[station])
 for key,values in [('all_periods',None)]+[(k,[v]) for k,v in PERIODS.items()]:
  if values:c.filter('Time Period',values)
  fn=f'{slug}_{key}.tsv'
  r=c.export('Total Entries and Exits',fn)
  rows=r.pop('rows')
  if not rows or rows[0]!=['','Entries','Exits']:raise RuntimeError(f'Unexpected header {rows[:1]}')
  dates=[datetime.datetime.strptime(row[0],'%B %d, %Y').date().isoformat() for row in rows[1:] if row and row[0]]
  if len(dates)<1000:raise RuntimeError(f'Export too short: {station} {key} {len(dates)}')
  (ROOT/'raw'/fn).write_bytes((c.root/fn).read_bytes())
  r.update(station=station,time_period=key,source_period_label=values[0] if values else 'All',rows=len(dates),date_min=min(dates),date_max=max(dates),retrieved_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),view_url=c.view_url,filters={'day_of_week':'all seven','holiday':['No','Yes'],'station_name':[station],'time_period':values or 'All'})
  local_manifest.append(r)
  (ROOT/'raw'/f'{slug}_manifest.json').write_text(json.dumps(local_manifest,indent=2))
  print(station,key,len(dates),min(dates),max(dates),flush=True)
 (ROOT/'raw'/f'{slug}_commands.json').write_text(json.dumps(c.command_results,indent=2))

 return local_manifest

if __name__=='__main__':
 from concurrent.futures import ThreadPoolExecutor
 with ThreadPoolExecutor(max_workers=2) as pool:
  for result in pool.map(collect,STATIONS):manifest.extend(result)
 (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2))
