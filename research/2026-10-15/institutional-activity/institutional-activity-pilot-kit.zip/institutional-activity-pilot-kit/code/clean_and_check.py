"""Validate the downloaded aggregates and build a tidy data panel (stdlib only).
Run: python3 code/clean_and_check.py
This validates data availability; it does not estimate predictive performance.
"""
from pathlib import Path
import json,csv,io,datetime,hashlib,collections
ROOT=Path(__file__).resolve().parents[1]
START=datetime.date(2023,1,1); END=datetime.date(2026,5,8)
EXPECTED={START+datetime.timedelta(days=i) for i in range((END-START).days+1)}
manifest=json.loads((ROOT/'manifest.json').read_text())
assert len(manifest)==12, 'Expected four stations and three time selections'
panel=[];quality=[];lookup={}
for item in manifest:
 path=ROOT/'raw'/item['filename'];raw=path.read_bytes()
 assert hashlib.sha256(raw).hexdigest()==item['sha256'], f'Hash mismatch: {path.name}'
 rows=list(csv.reader(io.StringIO(raw.decode('utf-16')),delimiter='\t'))
 assert rows[0]==['','Entries','Exits'],f'Header changed: {path.name}'
 dates=[];nulls=0;zeros=0
 for r in rows[1:]:
  if not r or not r[0]:continue
  d=datetime.datetime.strptime(r[0],'%B %d, %Y').date();dates.append(d)
  counts=[]
  for v in r[1:3]:
   if v.strip() in ('','Null','null'):counts.append(None);nulls+=1
   else:
    x=int(v.replace(',',''));assert x>=0;counts.append(x);zeros+=x==0
  row={'service_date':d.isoformat(),'station':item['station'],'time_period':item['time_period'],'entries':counts[0],'exits':counts[1]}
  assert (d,item['station'],item['time_period']) not in lookup,'Duplicate station/date/period'
  lookup[d,item['station'],item['time_period']]=row;panel.append(row)
 quality.append({'file':path.name,'rows':len(dates),'min_date':min(dates).isoformat(),'max_date':max(dates).isoformat(),'missing_dates':[d.isoformat() for d in sorted(EXPECTED-set(dates))],'duplicate_dates':len(dates)-len(set(dates)),'null_count_cells':nulls,'zero_count_cells':zeros})
violations=[]
for d in EXPECTED:
 for st in sorted({i['station'] for i in manifest}):
  a=lookup.get((d,st,'all_periods'));p=lookup.get((d,st,'pm_peak'));e=lookup.get((d,st,'evening'))
  if not all([a,p,e]):continue
  for k in ['entries','exits']:
   if None not in (a[k],p[k],e[k]) and p[k]+e[k]>a[k]:violations.append([d.isoformat(),st,k,a[k],p[k],e[k]])
assert not violations,f'Subperiod counts exceed all-period totals: {violations[:3]}'
panel.sort(key=lambda r:(r['service_date'],r['station'],r['time_period']))
with (ROOT/'station_counts.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['service_date','station','time_period','entries','exits']);w.writeheader();w.writerows(panel)
events=list(csv.DictReader((ROOT/'event_registry.csv').open()))
coverage=[]
for ev in events:
 d=datetime.date.fromisoformat(ev['washington_action_date'])
 for offset in range(-14,3):
  date=d+datetime.timedelta(days=offset)
  for st in sorted({i['station'] for i in manifest}):
   for per in ['pm_peak','evening']:
    row=lookup.get((date,st,per))
    coverage.append({'event_id':ev['event_id'],'days_from_action_date':offset,'complete_before_midnight_cutoff':offset<0,**(row or {'service_date':date.isoformat(),'station':st,'time_period':per,'entries':None,'exits':None})})
with (ROOT/'analysis'/'event_window_counts.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(coverage[0]));w.writeheader();w.writerows(coverage)
summary={'station_count':len({i['station'] for i in manifest}),'time_selections':3,'start':START.isoformat(),'end':END.isoformat(),'calendar_days':len(EXPECTED),'panel_rows':len(panel),'count_cells':2*len(panel),'period_sum_violations':violations,'files':quality,'event_window_rows':len(coverage),'note':'An archive coverage and consistency check, not an anomaly or predictive backtest. Missing values remain missing; zeros remain recorded zeros. Source date filters were not changed; these bounds describe this export, not the full source archive.'}
(ROOT/'analysis'/'quality_report.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='files'},indent=2))
print('Missing date rows:',sum(len(q['missing_dates']) for q in quality),'Null count cells:',sum(q['null_count_cells'] for q in quality),'Recorded zero count cells:',sum(q['zero_count_cells'] for q in quality))
