"""Read and export a public WMATA dashboard as an anonymous guest.

Only the dashboard's permitted filters and CSV-export commands are used.
No accounts, credentials, saved views or source data are changed.
"""
import urllib.request, urllib.parse, urllib.error, http.cookiejar
import json, uuid, pathlib, csv, io, hashlib

HOST='https://exttabanalytics.wmata.com'
BOOK='RidershipDataPortal-MetroRailRidershipSummary'

def multipart(fields):
    boundary='----publicdata'+uuid.uuid4().hex
    text=''.join('--'+boundary+'\r\nContent-Disposition: form-data; name="'+k+'"\r\n\r\n'+str(v)+'\r\n' for k,v in fields.items())+'--'+boundary+'--\r\n'
    return text.encode(),{'Content-Type':'multipart/form-data; boundary='+boundary}

def parts(raw):
    text=raw.decode();out=[]
    while text:
        length,sep,text=text.partition(';')
        if not sep:break
        length=int(length);out.append(json.loads(text[:length]));text=text[length:]
    return out

class PublicTableau:
    def __init__(self, slug, directory):
        self.root=pathlib.Path(directory);self.root.mkdir(parents=True,exist_ok=True)
        self.op=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        self.slug=slug;self.query=urllib.parse.urlencode({':embed':'yes',':showVizHome':'no',':showTabs':'true'})
        self.view_url=f'{HOST}/views/{BOOK}/{slug}?{self.query}'
        self.read(self.view_url)
        self.cfg=json.loads(self.read(f'{HOST}/vizql/w/{BOOK}/v/{slug}/startSession/viewing?{self.query}',b'',{'Accept':'application/json'}))
        if not self.cfg.get('is_guest') or not self.cfg.get('allow_export_data'):
            raise RuntimeError('This method requires a public guest session with data export enabled.')
        self.base=HOST+self.cfg['vizql_root'];self.session=self.cfg['sessionid']
        body=urllib.parse.urlencode({'sheet_id':urllib.parse.unquote(self.cfg['sheetId']),'showTabs':'true','bootstrapWhenNotified':'true','stickySessionKey':self.cfg['stickySessionKey']}).encode()
        raw=self.read(self.base+'/bootstrapSession/sessions/'+self.session,body)
        self.initial=parts(raw)
        (self.root/'bootstrap.bin').write_bytes(raw)
        d=self.initial[0]['worldUpdate']['applicationPresModel']['workbookPresModel']['dashboardPresModel']
        self.dashboard=self.initial[0]['sheetName']
        self.zones=d['zones'];self.worksheets=[z['worksheet'] for z in self.zones.values() if z.get('zoneCommon',{}).get('zoneType')=='viz']
        self.filters={z['zoneCommon']['name']:z.get('presModelHolder',{}).get('quickFilterDisplay',{}).get('quickFilter',{}) for z in self.zones.values() if z.get('zoneCommon',{}).get('zoneType')=='filter'}
        self.command_results=[]
        self.export_options=self.command('tabsrv/export-crosstab-server-dialog',{'thumbnailUris':'{}'})
        notice=self.export_options['vqlCmdResponse']['layoutStatus']['applicationPresModel']['presentationLayerNotification'][0]
        self.export_sheets=notice['presModelHolder']['genExportCrosstabOptionsDialogPresModel']['thumbnailSheetPickerItems']
    def read(self,url,data=None,headers=None):
        try:
            with self.op.open(urllib.request.Request(url,data=data,headers=headers or {}),timeout=55) as response:
                return response.read()
        except urllib.error.HTTPError as e:
            detail=e.read()[:1500].decode(errors='replace')
            raise RuntimeError(f'HTTP {e.code}: {detail}') from e
    def command(self,name,fields):
        body,headers=multipart(fields)
        response=json.loads(self.read(self.base+'/sessions/'+self.session+'/commands/'+name,body,headers))
        if response.get('vqlCmdResponse',{}).get('cmdResultList'):
            for item in response['vqlCmdResponse']['cmdResultList']:
                if item.get('commandReturn',{}).get('error'):raise RuntimeError(str(item))
        self.command_results.append({'command':name,'fields':fields})
        return response
    def filter(self,caption,values):
        return self.command('tabdoc/dashboard-categorical-filter',{'dashboard':self.dashboard,'qualifiedFieldCaption':caption,'exclude':'false','filterUpdateType':'filter-replace','filterValues':json.dumps(values)})
    def export(self,sheet,filename):
        item=next(s for s in self.export_sheets if s['sheetName']==sheet)
        result=self.command('tabsrv/export-crosstab-to-csvserver',{'sheetdocId':item['sheetdocId'],'useTabs':'true','sendNotifications':'true'})
        notices=result['vqlCmdResponse']['layoutStatus']['applicationPresModel']['presentationLayerNotification']
        key=None
        for n in notices:
            holder=n['presModelHolder']
            if 'genExportFilePresModel' in holder:key=holder['genExportFilePresModel']['resultKey']
            if 'genFileDownloadPresModel' in holder:key=holder['genFileDownloadPresModel']['tempfileKey']
        if not key:raise RuntimeError('No export file was returned.')
        url=self.base+'/tempfile/sessions/'+self.session+'/?'+urllib.parse.urlencode({'key':key,'keepfile':'yes','attachment':'yes'})
        raw=self.read(url);(self.root/filename).write_bytes(raw)
        text=raw.decode('utf-16') if raw[:2] in [b'\xff\xfe',b'\xfe\xff'] else raw.decode('utf-8-sig')
        rows=list(csv.reader(io.StringIO(text),delimiter='\t'))
        return {'filename':filename,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'rows':rows}

if __name__=='__main__':
    client=PublicTableau('TotalEntriesandExitsbyDay','tmp/activity-audit/total_day')
    print('DASHBOARD',client.dashboard,'SHEETS',client.worksheets,flush=True)
    for name,f in client.filters.items():
        print('FILTER',name,f.get('selectionSummary'),f.get('valueMin'),f.get('valueMax'),flush=True)
    client.filter('Day of Week',['Mon','Tue','Wed','Thu','Fri','Sat','Sun'])
    client.filter('Holiday',['No','Yes'])
    client.filter('Station Name',['Pentagon'])
    sheet=next(s for s in client.worksheets if s!='Data Range')
    r=client.export(sheet,'pentagon_all_periods.tsv')
    print('EXPORT',{k:v for k,v in r.items() if k!='rows'},'FIRST',r['rows'][:5],'LAST',r['rows'][-3:],flush=True)
    (client.root/'command_log.json').write_text(json.dumps(client.command_results,indent=2))
