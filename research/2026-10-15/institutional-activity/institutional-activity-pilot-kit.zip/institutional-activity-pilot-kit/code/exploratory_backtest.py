"""Offline first-pass retrospective screen, NOT a validated prediction model.
Python standard library only. See PILOT_PROTOCOL.txt and implementation memo.
"""
from pathlib import Path
from datetime import date,timedelta
from statistics import median
import csv,json,math,hashlib
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'analysis'
STATIONS=['Pentagon','Pentagon City','Rosslyn','Crystal City'];CONTROLS=STATIONS[1:]
parse=date.fromisoformat

def nth(y,m,weekday,n):
 d=date(y,m,1);return d+timedelta(days=(weekday-d.weekday())%7+7*(n-1))
def observed(d):
 return d-timedelta(days=1) if d.weekday()==5 else d+timedelta(days=1) if d.weekday()==6 else d
holidays=set()
for y in range(2022,2028):
 holidays.update(observed(date(y,m,d)) for m,d in [(1,1),(6,19),(7,4),(11,11),(12,25)])
 holidays.update([nth(y,1,0,3),nth(y,2,0,3),nth(y,9,0,1),nth(y,10,0,2),nth(y,11,3,4)])
 d=date(y,5,31);holidays.add(d-timedelta(days=d.weekday()))
extras={parse(d) for d in ['2024-12-24','2025-01-09','2025-12-24','2025-12-26']}

def between(d,a,b):return parse(a)<=d<=parse(b)
def exclusion(d,st):
 if d in holidays:return 'observed_federal_holiday'
 if d in extras:return 'special_federal_closure'
 if between(d,'2025-10-01','2025-11-12'):return 'federal_shutdown'
 if between(d,'2026-01-25','2026-01-28') or between(d,'2026-02-22','2026-02-23'):return 'documented_severe_weather'
 if st in ['Crystal City','Pentagon City'] and any(between(d,a,b) for a,b in [('2026-02-14','2026-02-16'),('2026-02-21','2026-02-22'),('2026-02-28','2026-03-01')]):return 'documented_construction_or_shuttle'
 return ''

raw={}
for r in csv.DictReader((ROOT/'station_counts.csv').open()):
 raw[parse(r['service_date']),r['station'],r['time_period']]={k:int(r[k]) if r[k] else None for k in ['entries','exits']}
dates=sorted({k[0] for k in raw})
base={}
for d in dates:
 for st in STATIONS:
  p=raw.get((d,st,'pm_peak'),{}).get('entries');e=raw.get((d,st,'evening'),{}).get('entries')
  reason=exclusion(d,st)
  if p is None or e is None:reason=reason or 'missing_counts'
  elif p+e<1000:reason=reason or 'traffic_below_1000'
  base[d,st]={'date':d.isoformat(),'station':st,'pm_entries':p,'evening_entries':e,'late_share':e/(p+e) if p is not None and e is not None and p+e else None,'excluded_reason':reason}
station_scores={}
for d in dates:
 for st in STATIONS:
  row=dict(base[d,st]);hist=[]
  for w in range(1,17):
   b=base.get((d-timedelta(weeks=w),st))
   if b and not b['excluded_reason']:hist.append(b)
   if len(hist)==12:break
  row['baseline_n']=len(hist)
  row['baseline_share']=median([b['late_share'] for b in hist]) if len(hist)>=8 else None
  row['baseline_evening_entries']=median([b['evening_entries'] for b in hist]) if len(hist)>=8 else None
  row['baseline_pm_entries']=median([b['pm_entries'] for b in hist]) if len(hist)>=8 else None
  if not row['excluded_reason'] and len(hist)<8:row['excluded_reason']='insufficient_baseline'
  row['share_deviation']=row['late_share']-row['baseline_share'] if not row['excluded_reason'] else None
  station_scores[d,st]=row
scores=[]
for d in dates:
 r=dict(station_scores[d,'Pentagon']);valid=[station_scores[d,st]['share_deviation'] for st in CONTROLS if not station_scores[d,st]['excluded_reason']]
 r['control_count']=len(valid);r['controls_median_deviation']=median(valid) if len(valid)>=2 else None
 if not r['excluded_reason'] and len(valid)<2:r['excluded_reason']='insufficient_controls'
 r['adjusted_score']=r['share_deviation']-median(valid) if not r['excluded_reason'] else None
 scores.append(r)
cal=[r for r in scores if r['date'].startswith('2024') and r['adjusted_score'] is not None]
ordered=sorted(r['adjusted_score'] for r in cal);budget=len(ordered)//15
threshold=ordered[len(ordered)-budget-1]
for r in scores:r['flag']=r['adjusted_score'] is not None and r['adjusted_score']>threshold

def write_csv(path,rows):
 with path.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
write_csv(OUT/'daily_exploratory_scores.csv',scores)
write_csv(OUT/'station_exploratory_scores.csv',list(station_scores.values()))
idx={parse(r['date']):r for r in scores}
def window(cutoff):
 days=[idx.get(cutoff-timedelta(days=i)) for i in [3,2,1]]
 good=[r for r in days if r and r['adjusted_score'] is not None]
 return {'cutoff':cutoff.isoformat(),'valid_evenings':len(good),'max_score':max(r['adjusted_score'] for r in good) if len(good)>=2 else None,'flag':any(r['flag'] for r in good) if len(good)>=2 else None,'days':[{'date':r['date'],'evening_entries':r['evening_entries'],'baseline_evening_entries':r['baseline_evening_entries'],'pm_entries':r['pm_entries'],'late_share':r['late_share'],'baseline_share':r['baseline_share'],'adjusted_score':r['adjusted_score'],'flag':r['flag'],'excluded_reason':r['excluded_reason']} for r in days if r]}
background=[window(d) for d in dates if between(d,'2025-01-01','2026-03-31') and d.weekday()==5]
case_dates={parse(r['washington_action_date']) for r in csv.DictReader((ROOT/'event_registry.csv').open())}
background=[w for w in background if parse(w['cutoff']) not in case_dates]
events=[]
for ev in csv.DictReader((ROOT/'event_registry.csv').open()):
 w=window(parse(ev['washington_action_date']));w['event_id']=ev['event_id'];w['case']=ev['case']
 matches=[b['max_score'] for b in background if b['valid_evenings']==w['valid_evenings'] and b['max_score'] is not None]
 w['matched_background_windows']=len(matches)
 w['percentile_vs_other_saturday_windows']=100*sum(v<=w['max_score'] for v in matches)/len(matches) if matches and w['max_score'] is not None else None
 if ev['event_id']=='venezuela_2026':w['stricter_midnight_jan_2_sensitivity']=window(parse('2026-01-02'))
 events.append(w)
test=[r for r in scores if '2025-01-01'<=r['date']<='2026-03-31']
valid=[r for r in test if r['adjusted_score'] is not None];flagged=[r for r in valid if r['flag']]
episodes=[]
for r in flagged:
 d=parse(r['date'])
 if episodes and (d-parse(episodes[-1]['last_date'])).days<=2:episodes[-1]['last_date']=r['date'];episodes[-1]['flagged_dates'].append(r['date'])
 else:episodes.append({'first_date':r['date'],'last_date':r['date'],'flagged_dates':[r['date']]})
# Fixed-baseline synthetic sensitivity: increase only target evening passages.
# This is not a workforce estimate or a longitudinal simulation.
noncase=[r for r in valid if not any(abs((parse(r['date'])-d).days)<=7 for d in case_dates)]
synthetic=[]
for extra in [250,500,1000]:
 newly=0;total=0
 for r in noncase:
  e=r['evening_entries']+extra;p=r['pm_entries']
  s=e/(p+e)-r['baseline_share']-r['controls_median_deviation']
  total+=s>threshold;newly+=(s>threshold and not r['flag'])
 synthetic.append({'synthetic_extra_evening_passages':extra,'eligible_noncase_dates':len(noncase),'flagged_after_injection':total,'newly_flagged_dates':newly,'fraction_flagged_after_injection':total/len(noncase)})
result={'status':'Exploratory first pass; incomplete disruption chronology and event universe; not validated prediction','baseline_rule':'Previous 12 valid same weekdays within 16 weeks; minimum 8','minimum_station_volume_pm_plus_evening':1000,'calibration_year':2024,'calibration_scored_dates':len(cal),'calibration_flagged_dates':sum(r['flag'] for r in cal),'threshold_percentage_points':100*threshold,'evaluation_period':'2025-01-01 to 2026-03-31','evaluation_calendar_days':len(test),'evaluation_scored_dates':len(valid),'evaluation_flagged_dates':len(flagged),'flagged_per_30_scored_dates':30*len(flagged)/len(valid),'background_alert_episodes':len(episodes),'events':events,'synthetic_sensitivity':synthetic,'all_flagged_dates':[r['date'] for r in flagged],'alert_episodes':episodes,'source_publication_lag_days':7,'predictive_validation':False}
(OUT/'exploratory_results.json').write_text(json.dumps(result,indent=2))
(OUT/'backtest_code.sha256').write_text(hashlib.sha256(Path(__file__).read_bytes()).hexdigest()+'  code/exploratory_backtest.py\n')
print(json.dumps(result,indent=2))
