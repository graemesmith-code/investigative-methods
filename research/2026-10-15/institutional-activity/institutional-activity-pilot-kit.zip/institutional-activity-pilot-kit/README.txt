INSTITUTIONAL ACTIVITY: RETROSPECTIVE PILOT KIT
Prepared 15 October 2026

DECISION
Read RESULTS.txt first. A zero-data-fee retrospective first pass has now been
run using Washington Metro's published station totals. Neither Iran pre-case
window triggered the fixed rule; Venezuela was unscorable under the chosen
volume and holiday rules. Do not deploy this measure as a standalone warning
signal. The archive and runnable analysis remain a useful pilot benchmark.

This establishes data feasibility and a negative exploratory finding. It does
NOT establish a predictive signal.
The public rail archive is published on a seven-day lag. It can help answer
whether an aggregate precursor existed, but cannot demonstrate that this
public feed would have alerted a newsroom in time. No source satisfying all
three requirements -- very cheap, institution-relevant and near-real-time,
with a verified historical archive -- has yet been established by this audit.

WHAT IS HERE
station_counts.csv: 14,688 rows. One row per station, service date and time
selection, with separate entry and exit counts. Four stations: Pentagon,
Pentagon City, Rosslyn and Crystal City. Date coverage: 2023-01-01 through
2026-05-08, 1,224 days. Three selections: all_periods; pm_peak (15:00-19:00);
evening (19:00-midnight), in Washington local time.

raw/: 12 unaltered public UTF-16 tab-separated exports, export command logs
and per-station provenance records. These contain aggregate counts only.
manifest.json: source URLs, filters, retrieval times and file checksums.
code/acquire.py: public guest export workflow; Python standard library only.
code/tableau_public.py: supporting export client; no account or API key.
code/clean_and_check.py: reproducible cleaning and consistency checks.
event_registry.csv: the three requested example cases and source links.
analysis/event_window_counts.csv: descriptive extracts from 14 days before
through 2 days after each action date. These are not anomaly scores.
analysis/quality_report.json: coverage, nulls, zeros and consistency results.
analysis/known_confounders.csv: starter list of documented disruptions.
PILOT_PROTOCOL.txt: original specification, preserved as written before scoring.
RESULTS.txt: findings, limitations and recommendation from the first pass.
code/exploratory_backtest.py: runnable retrospective screen and sensitivity test.
analysis/IMPLEMENTATION_BEFORE_SCORING.txt: clarifications fixed before scoring.
analysis/exploratory_results.json: machine-readable results.
analysis/daily_exploratory_scores.csv: every daily target score and exclusion.
analysis/station_exploratory_scores.csv: station-specific diagnostics.
SOURCES.txt: official source URLs and what each supports.

VALIDATION COMPLETED
All 12 exports contain all 1,224 dates, without duplicate date rows or blank
count cells. Counts are nonnegative integers. Afternoon plus evening counts
never exceed the corresponding all-period totals. Six zero count cells are
preserved as recorded, not converted to missing values. Passing these checks
does not establish source accuracy, station operations or causal meaning.
File checksums are verified by the cleaning script.

WHAT THE COUNTS MEAN
Entries mean entering the rail system at that station; exits mean leaving the
rail system there. At an office-area station, entries may reflect people
leaving the area by rail, but their employer and purpose are unknown. These
are passenger passages, not unique people, building occupancy or a census of
Pentagon employees. Bus transfers, visitors and unrelated local activity can
all matter. Transfers behind faregates do not create new entries. Drivers
and people who remain at work beyond train operating hours are not measured.

The public portal describes its figures as preliminary. Sensor calibration,
faregate changes and revisions may affect them. A download today does not
preserve exactly what was published on each historical day. The current
source view's date filter ended May 8, 2026; this is the verified export
boundary, not a claim that the underlying archive stops on that date.

IMPORTANT TIME CONVENTION
Metro assigns a service day from 04:00 to 03:59 the next calendar day.
Consequently, an all-period total dated Friday includes early Saturday.
The two separately exported afternoon/evening blocks avoid that ambiguity
for a midnight cutoff. Do not use Friday's all-period total as if it were
fully observed by Friday midnight. No after-midnight time block was exported
separately for this pilot.

EVENT DATE CONVENTION
Midnight Hammer is often described as June 22, 2025, the date in Iran. The
reported impacts were on June 21 in Washington. The registry distinguishes
these dates. Its midnight cutoffs are analysis conventions before reported
impacts, not verified mission-launch or first-public-report timestamps.
The Venezuela operation included activity overnight January 2-3. An honest
warning test must resolve that timeline before calling January 2 evening
counts a pre-operation signal. Results use these cutoffs provisionally; the Venezuela result is unscorable
under both its provisional cutoff and a stricter cutoff.

REPRODUCE WITHOUT NETWORK
Unzip this directory, then run:
  python3 code/clean_and_check.py
  python3 code/exploratory_backtest.py
Python 3.10 or later is recommended. No additional packages are required.
The script rewrites the cleaned CSV, event extracts and quality report.

RE-DOWNLOAD (OPTIONAL)
  python3 code/acquire.py
This makes anonymous public guest requests and uses permitted dashboard
filters and export commands. It does not alter the underlying source or save
a public view. It uses two independent sessions at a time. Tableau's interface
can change; this is a tested acquisition method, not an officially supported
WMATA API contract. The server's default date selection may change, so inspect
manifest.json and revise the expected coverage in clean_and_check.py for a
new export. For the frozen backtest, retain the included raw files unchanged.
The source page also supports manual data downloads if automation changes.

COST AND NEXT DECISION
Verified data acquisition fee: $0; no subscription, purchase or account was
required. A fuller methods review is estimated at 3-5 analyst working days,
using an existing computer. This is a planning estimate, not a vendor quote,
and excludes a comprehensive military-event chronology or long-term service.

Use the retrospective pilot to decide whether faster aggregate data would be
worth pursuing. Do not buy advertising-technology data or build a live alert
service on the strength of three selected military cases. A positive archive
finding would justify investigating whether a provider can publish similarly
broad counts promptly; that availability and price are not established here.
No one has been contacted and no recurring monitoring has been scheduled.
